Flair in Cola — Columbia Women in Hospitality Collective
Static website bundle (generated)

Files:
- index.html
- about.html
- events.html
- membership.html
- contact.html
- css/style.css
- js/script.js
- assets/logo.svg

How to use:
1. Extract the zip.
2. Open index.html in a browser to preview locally.
3. To publish: upload the folder to GitHub Pages, Netlify, Vercel, or any static host.

Suggested next steps:
- Replace placeholder logo.svg with a full brand mark.
- Add real event dates and venue details.
- Connect a simple backend or form service (Formspree, Netlify Forms) for production contact and membership handling.
